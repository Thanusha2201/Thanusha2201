<?php

namespace Drupal\config_form\Form;

use Drupal\Core\Database\Database;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\Core\Link;
use Drupal\core\messenger;

class CustomConfigForm extends ConfigFormBase {

    /**
     * Settings Variable.
     */
    Const CONFIGNAME = "config.custom";

    /**
     * {@inheritdoc}
     */
    public function getFormId() {
        return "config.custom";
    }

    /**
     * {@inheritdoc}
     */

    protected function getEditableConfigNames() {
        return [
            static::CONFIGNAME,
        ];
    }
    
    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state) {
        $config = $this->config(static::CONFIGNAME);
        $form['deeplink'] = [
            '#type' => 'textfield',
            '#title' => 'deep link',
            '#default_value' => (isset($data['deeplink'])) ? $data['deeplink'] : '',       
           ];

        $form['actuallink'] = [
            '#type' => 'textfield',
            '#title' => 'actual link',
            '#default_value' => (isset($data['actuallink'])) ? $data['actuallink'] : '',  
                ];

        $form['action']['submit_form']= [
          '#type' => 'submit',
          '#value' => $this->t('Save'),
          '#submit' => [[$this, 'storeFieldDataIntoCustomTable']],
        ];

         $header = [
           'id' => $this
             ->t('ID'),
          'deeplink' => $this
              ->t('deeplink'),
            'actuallink' => $this
              ->t('actuallink'),
          'edit' => $this
              ->t('Edit'),
          'delete' => $this
              ->t('delete'),
          ];
          $options = \Drupal::database()->select('config_app', 'n') 
          ->fields('n', ['id', 'deeplink', 'actuallink']) ->execute()->fetchALL(\PDO::FETCH_ASSOC);
         

          foreach ($options as $record) {
            $edit_form_url = Url::fromRoute('config.edit', ['id' => $record['id']]);
            $delete_form_url = Url::fromRoute('config.delete', ['id' => $record['id']]);

            $edit_form_link = Link::fromTextAndUrl($this->t('Edit'), $edit_form_url);
            $delete_form_link = Link::fromTextAndUrl($this->t('Delete'), $delete_form_url);

            //$edit_link = $edit_form_link->toLink();
            $edit_string = $edit_form_link->toString(); 
            $delete_string = $delete_form_link->toString(); 
            //$edit_link = $string->getGeneratedLink();
            $data[] = [
              'id' => $record['id'],
              'deeplink' => $record['deeplink'],
              'actuallink' => $record['actuallink'],
              'edit' => $edit_string,
              'delete' => $delete_string

            ];
           //print_r($data);
          }
          
         
          $form['table'] = array(
            '#type' => 'tableselect',
            '#header' => $header,
            '#options' => $data,
            '#empty' => $this
              ->t('No link'),
          );
            return $form;
    }

    public function validateForm(array &$form, FormStateInterface $form_state) {
      parent::validateForm($form, $form_state);
      
      $deeplink = $form_state->getValue('deeplink');
      $actuallink = $form_state->getValue('actuallink');
  
      if (substr($deeplink, 0, 1) != '/') {
        // Set an error for the form element with a key of "title".
        $form_state->setErrorByName('deeplink', $this->t("enter path should be '/'. Example: /abc"));
      }

      $base_url = Url::fromRoute('<front>')->setAbsolute()->toString();

      print_r($base_url);
      
      $actuallink = str_replace($base_url, '', $actuallink);

      //print( $base_url);

      //if (\Drupal::service('path.alias_storage')->aliasExists($actuallink)) {
        //return true;

      //}

     // $path_alias_repository = \Drupal::service('path_alias.repository');
     // if ($path_alias_repository->lookupByAlias($deeplink)) {
        //var_dump($path_alias_repository);
         // return TRUE;
      //}

      $path_alias_repository = \Drupal::service('path_alias.repository');
      if (!$path_alias_repository->lookupByAlias($actuallink, 'en')) {
       //var_dump($path_alias_repository);
        //return TRUE;
       $form_state->setErrorByName('actuallink', $this->t("the url does not exist"));
      } 
    }
  /**
   * {@inheritdoc}
   */
  public function storeFieldDataIntoCustomTable(array &$form, FormStateInterface $form_state) {
    
	try{
		$conn = Database::getConnection();
		
		$field = $form_state->getValues();
	   
		$fields["deeplink"] = $field['deeplink'];
		$fields["actuallink"] = $field['actuallink'];
		
		
		  $conn->insert('config_app')
			   ->fields($fields)->execute();
		  \Drupal::messenger()->addMessage($this->t('The link has been succesfully saved'));
		 
	} catch(Exception $ex){
		\Drupal::logger('failed')->error($ex->getMessage());
	}
    
  }
 

}

