<?php

namespace Drupal\my_crud\Form;

use Drupal\Core\Database\Database;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\Core\Link;
use Drupal\core\messenger;
use Symfony\Component\HttpFoundation\RedirectResponse;

class MycrudForm extends FormBase {

    public function getFormid()
    {
        return 'mycrud_form';
    }   
    
public function buildform(array $form, FormStateInterface $form_state) {
    $conn = Database::getConnection();

    $record = [];
    if(issewt($_GET['id']))
    {
        $query = $conn->select('curd','m')->condition('id',$_GET['id'])->fields('m');
        $record = $query->execute()->fetchAssoc();
    }

    $form['name'] = [
        '#type' => 'textfield',
        '#title' => t('Name'),
        '#required' => TRUE,
        '#default_value' => (isset($record['name'])&&$_GET['id'])?$record['name']:'',
    ];

    $form['age'] = [
        '#type' => 'textfield',
        '#title' => t('age'),
        '#required' => TRUE,
        '#default_value' => (isset($record['age'])&&$_GET['id'])?$record['age']:'',
    ];

    $form['action'] = ['#type' => 'action',];
    $form['action']['reset'] = [
        '#type' => 'button',
        '#value' => t('Reset'),
        '#attributes' => ['onclick' => 'this.form.reset(); return false;',],
    ];

    $link = Url::formUserInput('/crud/');

    $form['action']['cancel'] = [
        '#markup' => Link::formTextAndUrl(t('back to page'),$link,['attributes'=>['class'=>'button']])->toString(),
    ];
    return $form;
    
}

public function validationForm(array &$form, FormStateInterface $form_state) {
    $name = $form_state->getValue('name');

    if(preg_match('/[A-Za-z]/',$name)) {
        $form_state->setErrorByName('name',$this->t('lllll'));
    }

    $age = $form_state->getValue('age');
    if(preg_match('/[A-Za-z]/',$age)) {
        $form_state->setErrorByName('age',$this->t('ppppp'));
    }
    parent::validateForm($form,$form_state);
}

public function submitForm(array &$form, FormStateInterface $form_state) {
    $field = $form_state->getValue();

    $name = $field['name'];
    $age = $field['age'];

    if(isset($_GET['id']))
    {
        $field = ['name'=>$name, 'age'=>$age];

        $query = \Drupal::database();
        $query->update('crud')->fields($field)->condition('id',$_GET['id'])->execute();
        $this->messenger()->addMessage('succcesss');
    }
    else{
        $field = ['name'=>$name, 'age'=>$age];

        $query = \Drupal::database();
        $query->insert('crud')->fields($field)->execute();
        $this->messenger()->addMessage('succcesssfull');

        $form_state->setRedirect('my_crud.mycrud_controller_listing');
    }
}
}