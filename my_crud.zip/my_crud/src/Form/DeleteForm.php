<?php
/**
* @file
* @Contains Drupal\my_crud\Form\DeleteForm.
*/
namespace Drupal\my_crud\Form;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Form\ConfirmFormBase;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Class DeleteForm
 * @package Drupal\my_crud\Form
 */
class DeleteForm extends FormBase {
    public $id;

    /**
     * {@inheritdoc}
     */
    public function getFormId() {
        return 'delete_form';
    }

    public function getQuestion() {
        return $this->t('Delete data');
    }

    public function getCancelUrl() {
        return new Url('my_crud.mycrud_controller_listing');
    }

    public function getDescription() {
        return $this->t('Do you want to delete data number %id ?', ['%id' => $this->id]);
    }

    /**
     * {@inheritdoc}
     */
    public function getConfirmText() {
        return $this->t('Delete it!');
    }

    /**
     * {@inheritdoc}
     */
    public function getCancelText() {
        return $this->t('Cancel');
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state, $id = NULL) {

        $this->id = $id;
        return parent::buildForm($form, $form_state);
    }

    /**
     * {@inheritdoc}
     */
    public function validateForm(array &$form, FormStateInterface $form_state) {
        parent::validateForm($form, $form_state);
    }

    /**
     * {@inheritdoc}
     */
    public function submitForm(array &$form, FormStateInterface $form_state) {
        $query = \Drupal::database();
        $query->delete('crud')
            ->condition('id', $this->id)
            ->execute();
        \Drupal::messenger()->addStatus('Successfully deleted.');
        
        $this->messenger()->addMessenger('deleted');

        $form_state->setRedirect('my_crud.mycrud_controller_listing');
        }
}