<?php

namespace Drupal\my_crud\Controller;

use Drupal\Core\Database\Database;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\Core\Link;
use Drupal\core\messenger;
use Symfony\Component\HttpFoundation\RedirectResponse;

class MycrudController extends ControllerBase {
    public function Listing() {
        $header = [
            'id' => $this
              ->t('ID'),
           'name' => $this
               ->t('name'),
             'age' => $this
               ->t('age'),
           'opt' => $this
               ->t('operation'),
           'opt1' => $this
               ->t('operation1'),
           ];

           $row = [];

           $conn = $conn->select('crud','m');
           $query->fields('m',['id','name','age']);
           $result = $query->execute()->fetchAll();

           foreach ($options as $record) {
                $delete = Url::formUserInput('/my_crud/form/delete/',$value->id);
                $edit = Url::formUserInput('/my_crud/form/data?id',$value->id);

                $row[] = ['id'=>$value->id,'name'=>$value->name,'age'=>$value->age,'opt'=>Link::fromTextAndUrl('Edit',$edit)
                ->toString(),'opt1'=>Link::>Link::fromTextAndUrl('Delete',$delete)
                ->toString(),];
           }
           $add = Url::fromUserInput('/my_crud/form/data');

           $text = 'Add user';

           $data['table'] = [
               '#type'=>'table',
               '#header'=> $header_table,
               '#row'=>$row,
               '#empty'=>t('no record'),
               '#caption'=>Link::formTextAndUrl($text,$add)->toString(),
           ];
           $this->messenger()->addMessage('record listed');

           return $data;
               
    }
}

