<?php

namespace Drupal\custom_form\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

class CustomForm extends FormBase {

    public function getFormId(){
        return 'custom_form';
    }
    public function buildForm(array $form, FormStateInterface $form_state) {

        $form['name'] = [
            '#type' => 'textfield',
            '#title' => t('Name'),
            '#default_value' => (isset($data['name'])) ? $data['name'] : '', 
            '#required' => TRUE,      
           ];
           $form['rollno'] = [
            '#type' => 'textfield',
            '#title' => t('rollno'),
            '#default_value' => (isset($data['rollno'])) ? $data['rollno'] : '', 
            '#required' => TRUE,      
           ];
           $form['email'] = [
            '#type' => 'textfield',
            '#title' => t('email'),
            '#default_value' => (isset($data['email'])) ? $data['email'] : '', 
            '#required' => TRUE,      
           ];
           $form['dob'] = [
            '#type' => 'date',
            '#title' => t('dob'),
            '#default_value' => (isset($data['dob'])) ? $data['dob'] : '', 
            '#required' => TRUE,      
           ];
        $form['phone_number'] = [
            '#type' => 'int',
            '#title' => t('phone_number'),
            '#default_value' => (isset($data['phone_number'])) ? $data['phone_number'] : '',  
           ];
        $form['gender'] = [
            '#type' => 'select',
            '#title' => t('gender'),
            '#options' => [
                'Male' => t('Male'),
                'Female' => t('Female'),
                'other' => t('other'),
            ],      
           ];
        $form['actions']['#type'] = 'actions';
        $form['action']['submit_form']= [
          '#type' => 'submit',
          '#value' => $this->t('Save'),
          '#button_type' => 'primary',
        ];
        return $form;
    }

    public function validateForm(array &$form, FormStateInterface $form_state) {
        if(strlen($form_state->getValue('rollno'))<8) {
            $form_state->setErrorByName('rollno', $this->t('enter roll no'));
        }
        if(strlen($form_state->getValue('phone_number'))<10) {
            $form_state->setErrorByName('phone_number', $this->t('enter phone number'));
        }
    }

    public function submitForm(array &$form, FormStateInterface $form_state) {
        // drupal_set_message($this->t('@can_name ,Your application is being submitted!', array('@can_name' => $form_state->getValue('candidate_name'))));
         foreach ($form_state->getValues() as $key => $value) {
           drupal_set_message($key . ': ' . $value);
         }
        }
}