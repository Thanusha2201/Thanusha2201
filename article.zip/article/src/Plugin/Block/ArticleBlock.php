<?php
/**
 * @file
 * Contains \Drupal\article\Plugin\Block\XaiBlock.
 */

namespace Drupal\article\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;



/**
 * Provides a 'article' block.
 *
 * @Block(
 *   id = "article_block",
 *   admin_label = @Translation("Article block"),
 *   category = @Translation("Custom article block example")
 * )
 */
class ArticleBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {

  // $database = \Drupal::database();
  // $nids = $database->select('node', 'n')
  // ->condition('n.status', 1, '=')
  // ->fields( 'n', 'nid')
   // $query->range(0,3);
  // ->execute()->fetchAll('nid', \PDO::FETCH_ASSOC);
   // $record = $result->fetchAll();
   // $uid = [];
  // var_dump($nids);
  // exit();
    
   //foreach($nids as $nid){
     
   //   $uid[] = $value->id;
   // }
   //$database = \Drupal::database();
   //$query = $connection->select('article', 'n');
   //$query->fields('n');
   //$result = $query->execute()->fetchAll();;
   
    

    //$output = [];

    //return [
      //'#markup' => $this->t('hello'),
     //'#theme' => 'custom_block',
     //'#data' => $output,
   // ];

   $form = \Drupal::formBuilder()->getForm('Drupal\article\Form\ArticleForm');

    return $form;
   }
}

