<?php

namespace Drupal\custom_block\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a 'Hello' Block.
 *
 * @Block(
 *   id = "ccustom_block",
 *   admin_label = @Translation("Hello block"),
 *   category = @Translation("Hello World"),
 * )
 */
class CustomBlock extends BlockBase {
  /**
   * {@inheritdoc}
   */
  public function build() {

    $database = \Drupal::database();

    $query = $database->select('node_field_data', 'n');
   //->condition('n.status', 1, '=')
    $query->fields('n');
   // $query->fields( 'n');
    $query->range(0,3);
    $result = $query->execute();
    $record = $result->fetchAll();
 
    $titles = [];
    // $uid = [];
   // var_dump($nids);
   //print '<pre>';
   //print_r($titles);
   //exit();
     
 
   //$database = \Drupal


   return [
     '#markup' => $this->t('hello welcome'),
   ];
  }
}