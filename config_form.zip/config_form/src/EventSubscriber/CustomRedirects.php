<?php

namespace Drupal\config_form\EventSubscriber;

use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Class CustomRedirects
 * @package Drupal\config_form\EventSubscriber
 *
 * Redirects /deeplink/* to '/actuallink/*'
 */
class CustomRedirects implements EventSubscriberInterface {

  public function checkForRedirection(RequestEvent $event) {

    //global $base_url;
    //$current_url = $base_root . request_uri();
    //echo $current_url;
   // global $base_url;
   // $current_url = $base_url . '/' . current_path();

    //to get the current full-path for a page 
    //$path = \Drupal::service('path.current')->getPath();
    //$queryParams = \Drupal::request()->query->all();

    //$path . "?" . http_build_query($queryParams);

    $request = $event->getRequest();
    $path = $request->getPathInfo();
    //var_dump($path);
    //exit;

   

    if(strpos($path, 'deeplink') !== false) {
      // Redirect old  urls
      $new_url = str_replace('deeplink','actuallink', $path);
      $new_response = new RedirectResponse($new_url, '301');
      $new_response->send();
    }

    // This is necessary because this also gets called on
    // node sub-tabs such as "edit", "revisions", etc.  This
    // prevents those pages from redirected.
    if ($request->attributes->get('_route') !== 'entity.node.canonical') {
      return;
    }

  }

  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents() {
    //The dynamic cache subscribes an event with priority 27. If you want that your code runs before that you have to use a priority >27:
    $events[KernelEvents::REQUEST][] = array('checkForRedirection', 29);
    return $events;
  }

}