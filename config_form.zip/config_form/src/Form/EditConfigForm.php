<?php

namespace Drupal\config_form\Form;

use Drupal\Core\Database\Database;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\Core\Link;
use Drupal\core\messenger;
use Symfony\Component\HttpFoundation\RedirectResponse;


class EditConfigForm extends ConfigFormBase {

    /**
     * Settings Variable.
     */
    Const CONFIGNAME = "edit.custom";

    /**
     * {@inheritdoc}
     */
    public function getFormId() {
        return "edit.custom";
    }

    /**
     * {@inheritdoc}
     */

    protected function getEditableConfigNames() {
        return [
            static::CONFIGNAME,
        ];
    }
    
    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state) {
        
        $id = \Drupal:: routeMatch()->getParameter('id');

        $query = \Drupal::database();
        $data = $query->select('config_app', 'e')
              ->fields('e',['id', 'deeplink', 'actuallink'])
              ->condition('e.id',$id,'=')
               ->execute()->fetchAssoc();

                //print_r($data);

        $config = $this->config(static::CONFIGNAME);
        $form['deeplink'] = [
            '#type' => 'textfield',
            '#title' => 'deep link',
            '#default_value' => (isset($data['deeplink'])) ? $data['deeplink'] : '',
        ];

        $form['actuallink'] = [
            '#type' => 'textfield',
            '#title' => 'actual link',
            '#default_value' => (isset($data['actuallink'])) ? $data['actuallink'] : '',
        ];
       
    
    $form['submit'] = [
      '#type' => 'submit',
      '#button_type' => 'primary',
      '#default_value' => $this->t('update') ,
    ];
      
        return $form;
    }
    
    public function validateForm(array &$form, FormStateInterface $form_state) {
        parent::validateForm($form, $form_state);
        
        $deeplink = $form_state->getValue('deeplink');
        $actuallink = $form_state->getValue('actuallink');
    
        if (substr($deeplink, 0, 1) != '/') {
          // Set an error for the form element with a key of "title".
          $form_state->setErrorByName('deeplink', $this->t("enter path should be '/'. Example: /abc"));
        }
  
        $base_url = Url::fromRoute('<front>')->setAbsolute()->toString();
        $actuallink = str_replace($base_url, '', $actuallink);
  
        //print( $base_url);
  
        //if (\Drupal::service('path.alias_storage')->aliasExists($actuallink)) {
          //return true;
  
        //}
  
       // $path_alias_repository = \Drupal::service('path_alias.repository');
       // if ($path_alias_repository->lookupByAlias($deeplink)) {
          //var_dump($path_alias_repository);
           // return TRUE;
        //}
  
        $path_alias_repository = \Drupal::service('path_alias.repository');
        if (!$path_alias_repository->lookupByAlias($actuallink, 'en')) {
         //var_dump($path_alias_repository);
          //return TRUE;
         $form_state->setErrorByName('actuallink', $this->t("the url does not exist"));
        } 
      
    }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array & $form, FormStateInterface $form_state) {
	
        $id = \Drupal:: routeMatch()->getParameter('id');

		$conn = Database::getConnection();
		
		$field = $form_state->getValues();
	   
		$fields["deeplink"] = $field['deeplink'];
		$fields["actuallink"] = $field['actuallink'];
		
		
		  $conn->update('config_app')
			   ->fields($fields)->condition('id',$id)->execute();

            $edit_form_url = Url::fromRoute('config.custom')->toString();

            $response = new RedirectResponse($edit_form_url);
            $response->send();
		  \Drupal::messenger()->addMessage($this->t('The link has been succesfully saved'));
    
  }
 

}

